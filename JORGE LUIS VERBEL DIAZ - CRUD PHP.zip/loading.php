<!-- Spinner -->
<div id="preview-area" class="">
   <div class="dots-loader" id="Spinner">
      Loading...
   </div>
</div>
<!-- Spinner -->