<?php
	session_start();
	set_time_limit(200);
	ini_set('max_execution_time', 200);
	date_default_timezone_set('America/Bogota');
	$_SERVER['RUTA'] = "http://localhost/phppuro/";
?>